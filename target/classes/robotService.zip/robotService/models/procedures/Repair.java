package robotService.models.procedures;

import robotService.models.robots.BaseRobot;
import robotService.models.robots.interfaces.Robot;

public class Repair extends BaseProcedure {

    @Override
    public void doService(Robot robot, int procedureTime) {
        super.doService(robot, procedureTime);
    }
}
